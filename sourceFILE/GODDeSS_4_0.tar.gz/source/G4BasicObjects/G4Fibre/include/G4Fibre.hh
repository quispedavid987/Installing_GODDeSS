/*
 * author:      Erik Dietz-Laursonn
 * institution: Physics Institute 3A, RWTH Aachen University, Aachen, Germany
 * copyright:   Creative Commons Attribution-NonCommercial-ShareAlike 3.0 Unported License
 */


#ifndef G4FIBRE_H
#define G4FIBRE_H

#include <G4ThreeVector.hh>
#include <G4Transform3D.hh>
#include <G4Material.hh>
#include <G4VSolid.hh>
#include <G4LogicalVolume.hh>
#include <G4VPhysicalVolume.hh>
#include <G4PVPlacement.hh>
#include <G4OpticalSurface.hh>
#include <G4Colour.hh>
#include <G4SDManager.hh>

#include <FibreSensitiveDetector.hh>
#include <Properties.hh>
#include <PropertyToolsManager.hh>

#include <GODDeSS_DataStorage.hh>



// class variables begin with capital letters, local variables with small letters



///  a class generating the materials, volumes, and optical properties needed for a fibre and allows to access them.
class G4Fibre
{
public:

	/// <b> >>> construct a STRAIGHT fibre with a given START and END POINT </b>
	/**
	 *  Constructor to construct a <b> straight </b> fibre with a given <b> start </b> and <b> end point </b>:
	 *  - sets class variables to default values
	 *  - loads the property file and determines the fibres type
	 *  - sets the variables for the fibre properties and its placement (InitialiseVariables() \& GenerateTransformation())
	 *  - creates materials (DefineMaterials())
	 *  - constructs the volumes (ConstructVolumes())
	 */
	G4Fibre( G4String fibre_property_file,				/**< path to the file containing the G4Fibre%'s property */
		 G4VPhysicalVolume* mother_volume,			/**< volume that should be the G4Fibre%'s mother volume */
		 G4ThreeVector startPoint_relative_to_reference,	/**< G4Fibre%'s start point relative to the reference volume */
		 G4ThreeVector endPoint_relative_to_reference,		/**< G4Fibre%'s end point relative to the reference volume */
		 G4VPhysicalVolume* reference_volume,			/**< reference volume relative to which the G4Fibre will be orientated (if 0, the mother volume is the reference volume) */
		 G4Transform3D reference_transformation,		/**< transformation between mother volume and reference volume's mother volume (necessary if the reference volume is located in a different volume) */
		 G4String fibre_name_prefix,				/**< prefix of the G4Fibre%'s volumes' names (it will be extended to distinguish between different G4Fibre%s and different volumes of one G4Fibre) */
		 G4bool onlyInsideMother,				/**< if "true", only G4Fibre parts inside the G4Fibre%'s mother volume will be created */
		 G4bool cutAuntVolumesWithDaughters,			/**< if "true", only NO G4Fibre parts will be created inside the G4Fibre%'s aunt volumes (volumes that have been places into the same volume like the the mother volume) that contain daugther volumes themselves */
		 G4bool startPoint_reflective,				/**< the G4Fibre%'s beginning (start point) should have a reflective layer ("true" or "false") */
		 G4double startPoint_reflectivity,			/**< reflectivity of the G4Fibre%'s beginning (start point) reflective layer */
		 G4bool endPoint_roughened,				/**< the G4Fibre%'s end should be roughened ("true" or "false") */
		 G4double endPoint_sigmaAlpha,				/**< roughness of the G4Fibre%'s end (the parameter defines the standard deviation of the Gaussian distribution of micro-facets' normals around the average surface normal in degree or radian) */
		 G4bool constructSensitiveDetector,			/**< a sensitive detector should be constructed ("true" or "false") */
		 G4bool searchOverlaps,					/**< Geant should search for overlaps when placing the physical volumes of G4Fibre%'s ("true" or "false") */
		 PropertyToolsManager * propertyTools,			/**< pointer to the PropertyToolsManager that should be used */
		 GODDeSS_DataStorage * dataStorage			/**< pointer to the GODDeSS_DataStorage that should be used */
	       )
	// initialising the variables (doing it with default values, "" or "0" is just to prevent errors from wrongly initialised variables), this has to be done in the order of their appearance in the hh-file:
	: SearchOverlaps(searchOverlaps)
	, ConstructSensitiveDetector(constructSensitiveDetector)
	, PropertyTools(propertyTools)
	, DataStorage(dataStorage)
	, MotherVolume_physical(mother_volume)
	, ReferenceVolume_physical(reference_volume)
	, ReferenceVolume_transformation(reference_transformation)
	, StartPoint(startPoint_relative_to_reference)
	, EndPoint(endPoint_relative_to_reference)
	, FibreNamePrefix(fibre_name_prefix)
	, OnlyInsideMother(onlyInsideMother)
	, CutAuntVolumesWithDaughters(cutAuntVolumesWithDaughters)
	, Reflective(startPoint_reflective)
	, Reflective_thickness(1 * CLHEP::um)
	, Reflectivity(startPoint_reflectivity)
	, Roughened(endPoint_roughened)
	, Rough_thickness(1e-3 * CLHEP::nm)
	, Roughness(endPoint_sigmaAlpha)
	{
		if(ReferenceVolume_physical != MotherVolume_physical && ReferenceVolume_physical->GetMotherLogical() != MotherVolume_physical->GetLogicalVolume() && reference_transformation == G4Transform3D()) G4cerr << G4endl << "The reference volume is neither located in the mother volume nor is it the mother volume. This might lead to geometry problems, if no transformation between mother volume and reference volume's mother volume is defined!" << G4endl << G4endl;

		// set default values
		SetDefaults();

		Length = NAN;
		FibreTransformation_rel = G4Transform3D();
		ReplicationTransformation = G4Transform3D();

		FibreBent = false;
		BendingCircularCentre = G4ThreeVector(NAN, NAN, NAN);
		BendingAxis = G4ThreeVector(NAN, NAN, NAN);
		BendingRadius = NAN;
		BendingDeltaAngle = NAN;
		BendingStartAngle = NAN;
		BendingEndAngle = NAN;
		Reflective_bendingDeltaAngle = NAN;
		Rough_bendingDeltaAngle = NAN;

		// the obligatory parameters
		FibreProperties.load(fibre_property_file);

		if(FibreProperties.containsNumber("lightOutput") || FibreProperties.containsNumber("lightOutput_rel"))
		{
			IsScinti = true;
			FibreNamePrefix = FibreNamePrefix + "_(scinti)";
		}
		else if(PropertyTools->GetPropertyDistribution(FibreProperties, "epsilon"))
		{
			IsWLS = true;
			FibreNamePrefix = FibreNamePrefix + "_(WLS)";
		}

		// calculate variables and create materials:
		InitialiseVariables();
		GenerateTransformation("straight");
		DefineMaterials();

		// create the volumes
		ConstructVolumes("straight");

		// abort the whole programme, if a critical error occured
		if(CriticalErrorOccured) exit(1);
	}

// option to create replications: the first object will be placed at transf_relative_to_reference, the other number_of_replications - 1 objects will be placed at replication_transf relative to the previous one
	/// <b> >>> construct replications of a STRAIGHT fibre with a given START and END POINT </b>
	/**
	 *  Constructor to construct replications of a <b> straight </b> fibre with a given <b> start </b> and <b> end point </b>:
	 *  - sets class variables to default values
	 *  - loads the property file and determines the fibres type
	 *  - sets the variables for the fibre properties and its placement (InitialiseVariables() \& GenerateTransformation())
	 *  - creates materials (DefineMaterials())
	 *  - constructs the volumes (ConstructVolumes())
	 */
	G4Fibre( G4String fibre_property_file,				/**< path to the file containing the G4Fibre%'s property */
		 G4VPhysicalVolume* mother_volume,			/**< volume that should be the G4Fibre%'s mother volume */
		 G4ThreeVector startPoint_relative_to_reference,	/**< G4Fibre%'s start point relative to the reference volume */
		 G4ThreeVector endPoint_relative_to_reference,		/**< G4Fibre%'s end point relative to the reference volume */
		 G4VPhysicalVolume* reference_volume,			/**< reference volume relative to which the G4Fibre will be orientated (if 0, the mother volume is the reference volume) */
		 G4Transform3D reference_transformation,		/**< transformation between mother volume and reference volume's mother volume (necessary if the reference volume is located in a different volume) */
		 G4String fibre_name_prefix,				/**< prefix of the G4Fibre%'s volumes' names (it will be extended to distinguish between different G4Fibre%s and different volumes of one G4Fibre) */
		 G4bool onlyInsideMother,				/**< if "true", only G4Fibre parts inside the G4Fibre%'s mother volume will be created */
		 G4bool cutAuntVolumesWithDaughters,			/**< if "true", only NO G4Fibre parts will be created inside the G4Fibre%'s aunt volumes (volumes that have been places into the same volume like the the mother volume) that contain daugther volumes themselves */
		 G4bool startPoint_reflective,				/**< the G4Fibre%'s beginning (start point) should have a reflective layer ("true" or "false") */
		 G4double startPoint_reflectivity,			/**< reflectivity of the G4Fibre%'s beginning (start point) reflective layer */
		 G4bool endPoint_roughened,				/**< the G4Fibre%'s end should be roughened ("true" or "false") */
		 G4double endPoint_sigmaAlpha,				/**< roughness of the G4Fibre%'s end (the parameter defines the standard deviation of the Gaussian distribution of micro-facets' normals around the average surface normal in degree or radian) */
		 G4bool constructSensitiveDetector,			/**< a sensitive detector should be constructed ("true" or "false") */
		 G4bool searchOverlaps,					/**< Geant should search for overlaps when placing the physical volumes of G4Fibre%'s ("true" or "false") */
		 PropertyToolsManager * propertyTools,			/**< pointer to the PropertyToolsManager that should be used */
		 GODDeSS_DataStorage * dataStorage,			/**< pointer to the GODDeSS_DataStorage that should be used */
		 G4Transform3D replication_transf			/**< transformation of each replication, relative to the previous one */
	       )
	// initialising the variables (doing it with default values, "" or "0" is just to prevent errors from wrongly initialised variables), this has to be done in the order of their appearance in the hh-file:
	: SearchOverlaps(searchOverlaps)
	, ConstructSensitiveDetector(constructSensitiveDetector)
	, PropertyTools(propertyTools)
	, DataStorage(dataStorage)
	, MotherVolume_physical(mother_volume)
	, ReferenceVolume_physical(reference_volume)
	, ReferenceVolume_transformation(reference_transformation)
	, StartPoint(startPoint_relative_to_reference)
	, EndPoint(endPoint_relative_to_reference)
	, FibreNamePrefix(fibre_name_prefix)
	, OnlyInsideMother(onlyInsideMother)
	, CutAuntVolumesWithDaughters(cutAuntVolumesWithDaughters)
	, Reflective(startPoint_reflective)
	, Reflective_thickness(1 * CLHEP::um)
	, Reflectivity(startPoint_reflectivity)
	, Roughened(endPoint_roughened)
	, Rough_thickness(1e-3 * CLHEP::nm)
	, Roughness(endPoint_sigmaAlpha)
	, ReplicationTransformation(replication_transf)
	{
		if(ReferenceVolume_physical != MotherVolume_physical && ReferenceVolume_physical->GetMotherLogical() != MotherVolume_physical->GetLogicalVolume() && reference_transformation == G4Transform3D()) G4cerr << G4endl << "The reference volume is neither located in the mother volume nor is it the mother volume. This might lead to geometry problems, if no transformation between mother volume and reference volume's mother volume is defined!" << G4endl << G4endl;

		// set default values
		SetDefaults();

		Length = NAN;
		FibreTransformation_rel = G4Transform3D();

		FibreBent = false;
		BendingCircularCentre = G4ThreeVector(NAN, NAN, NAN);
		BendingAxis = G4ThreeVector(NAN, NAN, NAN);
		BendingRadius = NAN;
		BendingDeltaAngle = NAN;
		BendingStartAngle = NAN;
		BendingEndAngle = NAN;
		Reflective_bendingDeltaAngle = NAN;
		Rough_bendingDeltaAngle = NAN;

		// the obligatory parameters
		FibreProperties.load(fibre_property_file);

		if(FibreProperties.containsNumber("lightOutput") || FibreProperties.containsNumber("lightOutput_rel"))
		{
			IsScinti = true;
			FibreNamePrefix = FibreNamePrefix + "_(scinti)";
		}
		else if(PropertyTools->GetPropertyDistribution(FibreProperties, "epsilon"))
		{
			IsWLS = true;
			FibreNamePrefix = FibreNamePrefix + "_(WLS)";
		}

		// calculate variables and create materials:
		InitialiseVariables();
		GenerateTransformation("straight");
		DefineMaterials();

		// create the volumes
		ConstructVolumes("straight");

		// abort the whole programme, if a critical error occured
		if(CriticalErrorOccured) exit(1);
	}

	/// <b> >>> construct a STRAIGHT fibre with a given LENGTH and TRANSFORMATION </b>
	/**
	 *  Constructor to construct a <b> straight </b> fibre with a given <b> length </b> and <b> transformation </b>:
	 *  - sets class variables to default values
	 *  - loads the property file and determines the fibres type
	 *  - sets the variables for the fibre properties and its placement (InitialiseVariables() \& GenerateTransformation())
	 *  - creates materials (DefineMaterials())
	 *  - constructs the volumes (ConstructVolumes())
	 */
	G4Fibre( G4String fibre_property_file,			/**< path to the file containing the G4Fibre%'s property */
		 G4VPhysicalVolume* mother_volume,		/**< volume that should be the G4Fibre%'s mother volume */
		 G4double length,				/**< G4Fibre%'s length */
		 G4Transform3D transf_relative_to_reference,	/**< G4Fibre%'s transformation relative to the reference volume */
		 G4VPhysicalVolume* reference_volume,		/**< reference volume relative to which the G4Fibre will be orientated (if 0, the mother volume is the reference volume) */
		 G4Transform3D reference_transformation,	/**< transformation between mother volume and reference volume's mother volume (necessary if the reference volume is located in a different volume) */
		 G4String fibre_name_prefix,			/**< prefix of the G4Fibre%'s volumes' names (it will be extended to distinguish between different G4Fibre%s and different volumes of one G4Fibre) */
		 G4bool onlyInsideMother,			/**< if "true", only G4Fibre parts inside the G4Fibre%'s mother volume will be created */
		 G4bool cutAuntVolumesWithDaughters,		/**< if "true", only NO G4Fibre parts will be created inside the G4Fibre%'s aunt volumes (volumes that have been places into the same volume like the the mother volume) that contain daugther volumes themselves */
		 G4bool startPoint_reflective,			/**< the G4Fibre%'s beginning (start point) should have a reflective layer ("true" or "false") */
		 G4double startPoint_reflectivity,		/**< reflectivity of the G4Fibre%'s beginning (start point) reflective layer */
		 G4bool endPoint_roughened,			/**< the G4Fibre%'s end should be roughened ("true" or "false") */
		 G4double endPoint_sigmaAlpha,			/**< roughness of the G4Fibre%'s end (the parameter defines the standard deviation of the Gaussian distribution of micro-facets' normals around the average surface normal in degree or radian) */
		 G4bool constructSensitiveDetector,		/**< a sensitive detector should be constructed ("true" or "false") */
		 G4bool searchOverlaps,				/**< Geant should search for overlaps when placing the physical volumes of G4Fibre%'s ("true" or "false") */
		 PropertyToolsManager * propertyTools,		/**< pointer to the PropertyToolsManager that should be used */
		 GODDeSS_DataStorage * dataStorage		/**< pointer to the GODDeSS_DataStorage that should be used */
	       )
	// initialising the variables (doing it with default values, "" or "0" is just to prevent errors from wrongly initialised variables), this has to be done in the order of their appearance in the hh-file:
	: SearchOverlaps(searchOverlaps)
	, ConstructSensitiveDetector(constructSensitiveDetector)
	, PropertyTools(propertyTools)
	, DataStorage(dataStorage)
	, MotherVolume_physical(mother_volume)
	, ReferenceVolume_physical(reference_volume)
	, ReferenceVolume_transformation(reference_transformation)
	, Length(length)
	, FibreTransformation_rel(transf_relative_to_reference)
	, FibreNamePrefix(fibre_name_prefix)
	, OnlyInsideMother(onlyInsideMother)
	, CutAuntVolumesWithDaughters(cutAuntVolumesWithDaughters)
	, Reflective(startPoint_reflective)
	, Reflective_thickness(1 * CLHEP::um)
	, Reflectivity(startPoint_reflectivity)
	, Roughened(endPoint_roughened)
	, Rough_thickness(1e-3 * CLHEP::nm)
	, Roughness(endPoint_sigmaAlpha)
	{
		if(ReferenceVolume_physical != MotherVolume_physical && ReferenceVolume_physical->GetMotherLogical() != MotherVolume_physical->GetLogicalVolume() && reference_transformation == G4Transform3D()) G4cerr << G4endl << "The reference volume is neither located in the mother volume nor is it the mother volume. This might lead to geometry problems, if no transformation between mother volume and reference volume's mother volume is defined!" << G4endl << G4endl;

		// set default values
		SetDefaults();

		StartPoint = G4ThreeVector(NAN, NAN, NAN);
		EndPoint = G4ThreeVector(NAN, NAN, NAN);
		ReplicationTransformation = G4Transform3D();

		FibreBent = false;
		BendingCircularCentre = G4ThreeVector(NAN, NAN, NAN);
		BendingAxis = G4ThreeVector(NAN, NAN, NAN);
		BendingRadius = NAN;
		BendingDeltaAngle = NAN;
		BendingStartAngle = NAN;
		BendingEndAngle = NAN;
		Reflective_bendingDeltaAngle = NAN;
		Rough_bendingDeltaAngle = NAN;

		// the obligatory parameters
		FibreProperties.load(fibre_property_file);

		if(FibreProperties.containsNumber("lightOutput") || FibreProperties.containsNumber("lightOutput_rel"))
		{
			IsScinti = true;
			FibreNamePrefix = FibreNamePrefix + "_(scinti)";
		}
		else if(PropertyTools->GetPropertyDistribution(FibreProperties, "epsilon"))
		{
			IsWLS = true;
			FibreNamePrefix = FibreNamePrefix + "_(WLS)";
		}

		// calculate variables and create materials:
		InitialiseVariables();
		GenerateTransformation("straight");
		DefineMaterials();

		// create the volumes
		ConstructVolumes("straight");

		// abort the whole programme, if a critical error occured
		if(CriticalErrorOccured) exit(1);
	}

// option to create replications: the first object will be placed at transf_relative_to_reference, the other number_of_replications - 1 objects will be placed at replication_transf relative to the previous one
	/// <b> >>> construct replications of a STRAIGHT fibre with a given LENGTH and TRANSFORMATION </b>
	/**
	 *  Constructor to construct replications of a <b> straight </b> fibre with a given <b> length </b> and <b> transformation </b>:
	 *  - sets class variables to default values
	 *  - loads the property file and determines the fibres type
	 *  - sets the variables for the fibre properties and its placement (InitialiseVariables() \& GenerateTransformation())
	 *  - creates materials (DefineMaterials())
	 *  - constructs the volumes (ConstructVolumes())
	 */
	G4Fibre( G4String fibre_property_file,			/**< path to the file containing the G4Fibre%'s property */
		 G4VPhysicalVolume* mother_volume,		/**< volume that should be the G4Fibre%'s mother volume */
		 G4double length,				/**< G4Fibre%'s length */
		 G4Transform3D transf_relative_to_reference,	/**< G4Fibre%'s transformation relative to the reference volume */
		 G4VPhysicalVolume* reference_volume,		/**< reference volume relative to which the G4Fibre will be orientated (if 0, the mother volume is the reference volume) */
		 G4Transform3D reference_transformation,	/**< transformation between mother volume and reference volume's mother volume (necessary if the reference volume is located in a different volume) */
		 G4String fibre_name_prefix,			/**< prefix of the G4Fibre%'s volumes' names (it will be extended to distinguish between different G4Fibre%s and different volumes of one G4Fibre) */
		 G4bool onlyInsideMother,			/**< if "true", only G4Fibre parts inside the G4Fibre%'s mother volume will be created */
		 G4bool cutAuntVolumesWithDaughters,		/**< if "true", only NO G4Fibre parts will be created inside the G4Fibre%'s aunt volumes (volumes that have been places into the same volume like the the mother volume) that contain daugther volumes themselves */
		 G4bool startPoint_reflective,			/**< the G4Fibre%'s beginning (start point) should have a reflective layer ("true" or "false") */
		 G4double startPoint_reflectivity,		/**< reflectivity of the G4Fibre%'s beginning (start point) reflective layer */
		 G4bool endPoint_roughened,			/**< the G4Fibre%'s end should be roughened ("true" or "false") */
		 G4double endPoint_sigmaAlpha,			/**< roughness of the G4Fibre%'s end (the parameter defines the standard deviation of the Gaussian distribution of micro-facets' normals around the average surface normal in degree or radian) */
		 G4bool constructSensitiveDetector,		/**< a sensitive detector should be constructed ("true" or "false") */
		 G4bool searchOverlaps,				/**< Geant should search for overlaps when placing the physical volumes of G4Fibre%'s ("true" or "false") */
		 PropertyToolsManager * propertyTools,		/**< pointer to the PropertyToolsManager that should be used */
		 GODDeSS_DataStorage * dataStorage,		/**< pointer to the GODDeSS_DataStorage that should be used */
		 G4Transform3D replication_transf		/**< transformation of each replication, relative to the previous one */
	       )
	// initialising the variables (doing it with default values, "" or "0" is just to prevent errors from wrongly initialised variables), this has to be done in the order of their appearance in the hh-file:
	: SearchOverlaps(searchOverlaps)
	, ConstructSensitiveDetector(constructSensitiveDetector)
	, PropertyTools(propertyTools)
	, DataStorage(dataStorage)
	, MotherVolume_physical(mother_volume)
	, ReferenceVolume_physical(reference_volume)
	, ReferenceVolume_transformation(reference_transformation)
	, Length(length)
	, FibreTransformation_rel(transf_relative_to_reference)
	, FibreNamePrefix(fibre_name_prefix)
	, OnlyInsideMother(onlyInsideMother)
	, CutAuntVolumesWithDaughters(cutAuntVolumesWithDaughters)
	, Reflective(startPoint_reflective)
	, Reflective_thickness(1 * CLHEP::um)
	, Reflectivity(startPoint_reflectivity)
	, Roughened(endPoint_roughened)
	, Rough_thickness(1e-3 * CLHEP::nm)
	, Roughness(endPoint_sigmaAlpha)
	, ReplicationTransformation(replication_transf)
	{
		if(ReferenceVolume_physical != MotherVolume_physical && ReferenceVolume_physical->GetMotherLogical() != MotherVolume_physical->GetLogicalVolume() && reference_transformation == G4Transform3D()) G4cerr << G4endl << "The reference volume is neither located in the mother volume nor is it the mother volume. This might lead to geometry problems, if no transformation between mother volume and reference volume's mother volume is defined!" << G4endl << G4endl;

		// set default values
		SetDefaults();

		StartPoint = G4ThreeVector(NAN, NAN, NAN);
		EndPoint = G4ThreeVector(NAN, NAN, NAN);

		FibreBent = false;
		BendingCircularCentre = G4ThreeVector(NAN, NAN, NAN);
		BendingAxis = G4ThreeVector(NAN, NAN, NAN);
		BendingRadius = NAN;
		BendingDeltaAngle = NAN;
		BendingStartAngle = NAN;
		BendingEndAngle = NAN;
		Reflective_bendingDeltaAngle = NAN;
		Rough_bendingDeltaAngle = NAN;

		// the obligatory parameters
		FibreProperties.load(fibre_property_file);

		if(FibreProperties.containsNumber("lightOutput") || FibreProperties.containsNumber("lightOutput_rel"))
		{
			IsScinti = true;
			FibreNamePrefix = FibreNamePrefix + "_(scinti)";
		}
		else if(PropertyTools->GetPropertyDistribution(FibreProperties, "epsilon"))
		{
			IsWLS = true;
			FibreNamePrefix = FibreNamePrefix + "_(WLS)";
		}

		// calculate variables and create materials:
		InitialiseVariables();
		GenerateTransformation("straight");
		DefineMaterials();

		// create the volumes
		ConstructVolumes("straight");

		// abort the whole programme, if a critical error occured
		if(CriticalErrorOccured) exit(1);
	}

	/// <b> >>> construct a BENT fibre with a given BENDING AXIS, BENDING ANGLE, START and END POINT </b>
	/**
	 *  Constructor to construct a <b> bent </b> fibre with a given <b> bending axis </b>, <b> bending angle </b>, <b> start </b> and <b> end point </b>:
	 *  - sets class variables to default values
	 *  - loads the property file and determines the fibres type
	 *  - sets the variables for the fibre properties and its placement (InitialiseVariables() \& GenerateTransformation())
	 *  - creates materials (DefineMaterials())
	 *  - constructs the volumes (ConstructVolumes())
	 */
	G4Fibre( G4String fibre_property_file,				/**< path to the file containing the G4Fibre%'s property */
		 G4VPhysicalVolume* mother_volume,			/**< volume that should be the G4Fibre%'s mother volume */
		 G4ThreeVector startPoint_relative_to_reference,	/**< G4Fibre%'s start point relative to the reference volume */
		 G4ThreeVector endPoint_relative_to_reference,		/**< G4Fibre%'s end point relative to the reference volume */
		 G4double bending_delta_angle,				/**< G4Fibre%'s bending angle */
		 G4ThreeVector bending_axis,				/**< G4Fibre%'s bending axis */
		 G4VPhysicalVolume* reference_volume,			/**< reference volume relative to which the G4Fibre will be orientated (if 0, the mother volume is the reference volume) */
		 G4Transform3D reference_transformation,		/**< transformation between mother volume and reference volume's mother volume (necessary if the reference volume is located in a different volume) */
		 G4String fibre_name_prefix,				/**< prefix of the G4Fibre%'s volumes' names (it will be extended to distinguish between different G4Fibre%s and different volumes of one G4Fibre) */
		 G4bool onlyInsideMother,				/**< if "true", only G4Fibre parts inside the G4Fibre%'s mother volume will be created */
		 G4bool cutAuntVolumesWithDaughters,			/**< if "true", only NO G4Fibre parts will be created inside the G4Fibre%'s aunt volumes (volumes that have been places into the same volume like the the mother volume) that contain daugther volumes themselves */
		 G4bool startPoint_reflective,				/**< the G4Fibre%'s beginning (start point) should have a reflective layer ("true" or "false") */
		 G4double startPoint_reflectivity,			/**< reflectivity of the G4Fibre%'s beginning (start point) reflective layer */
		 G4bool endPoint_roughened,				/**< the G4Fibre%'s end should be roughened ("true" or "false") */
		 G4double endPoint_sigmaAlpha,				/**< roughness of the G4Fibre%'s end (the parameter defines the standard deviation of the Gaussian distribution of micro-facets' normals around the average surface normal in degree or radian) */
		 G4bool constructSensitiveDetector,			/**< a sensitive detector should be constructed ("true" or "false") */
		 G4bool searchOverlaps,					/**< Geant should search for overlaps when placing the physical volumes of G4Fibre%'s ("true" or "false") */
		 PropertyToolsManager * propertyTools,			/**< pointer to the PropertyToolsManager that should be used */
		 GODDeSS_DataStorage * dataStorage			/**< pointer to the GODDeSS_DataStorage that should be used */
	       )
	// initialising the variables (doing it with default values, "" or "0" is just to prevent errors from wrongly initialised variables), this has to be done in the order of their appearance in the hh-file:
	: SearchOverlaps(searchOverlaps)
	, ConstructSensitiveDetector(constructSensitiveDetector)
	, PropertyTools(propertyTools)
	, DataStorage(dataStorage)
	, MotherVolume_physical(mother_volume)
	, ReferenceVolume_physical(reference_volume)
	, ReferenceVolume_transformation(reference_transformation)
	, StartPoint(startPoint_relative_to_reference)
	, EndPoint(endPoint_relative_to_reference)
	, BendingAxis(bending_axis.perpPart(EndPoint - StartPoint) / bending_axis.perpPart(EndPoint - StartPoint).mag())
	, BendingDeltaAngle(bending_delta_angle)
	, FibreNamePrefix(fibre_name_prefix)
	, OnlyInsideMother(onlyInsideMother)
	, CutAuntVolumesWithDaughters(cutAuntVolumesWithDaughters)
	, Reflective(startPoint_reflective)
	, Reflective_thickness(1 * CLHEP::um)
	, Reflectivity(startPoint_reflectivity)
	, Roughened(endPoint_roughened)
	, Rough_thickness(1e-3 * CLHEP::nm)
	, Roughness(endPoint_sigmaAlpha)
	{
		if(ReferenceVolume_physical != MotherVolume_physical && ReferenceVolume_physical->GetMotherLogical() != MotherVolume_physical->GetLogicalVolume() && reference_transformation == G4Transform3D()) G4cerr << G4endl << "The reference volume is neither located in the mother volume nor is it the mother volume. This might lead to geometry problems, if no transformation between mother volume and reference volume's mother volume is defined!" << G4endl << G4endl;

		// set default values
		SetDefaults();

		FibreBent = true;
		BendingStartAngle = NAN;
		BendingEndAngle = NAN;
		Reflective_bendingDeltaAngle = NAN;
		Rough_bendingDeltaAngle = NAN;

		Length = NAN;
		FibreTransformation_rel = G4Transform3D();
		ReplicationTransformation = G4Transform3D();

		// get bending properties
		G4ThreeVector linkingVector = EndPoint - StartPoint;
		BendingCircularCentre = (EndPoint + StartPoint) / 2. - linkingVector.mag() / 2. / tan(BendingDeltaAngle / 2.) * linkingVector.cross(BendingAxis) / linkingVector.mag();
		BendingRadius = linkingVector.mag() / 2. / sin(BendingDeltaAngle / 2.);
		if(Reflective) Reflective_bendingDeltaAngle = 2. * asin(Reflective_thickness / 2. / BendingRadius);
		if(Roughened) Rough_bendingDeltaAngle = 2. * asin(Rough_thickness / 2. / BendingRadius);

		// the obligatory parameters
		FibreProperties.load(fibre_property_file);

		if(FibreProperties.containsNumber("lightOutput") || FibreProperties.containsNumber("lightOutput_rel"))
		{
			IsScinti = true;
			FibreNamePrefix = FibreNamePrefix + "_(scinti)";
		}
		else if(PropertyTools->GetPropertyDistribution(FibreProperties, "epsilon"))
		{
			IsWLS = true;
			FibreNamePrefix = FibreNamePrefix + "_(WLS)";
		}

		// calculate variables and create materials:
		InitialiseVariables();
		GenerateTransformation("bent");
		DefineMaterials();

		// create the volumes
		ConstructVolumes("bent");

		// abort the whole programme, if a critical error occured
		if(CriticalErrorOccured) exit(1);
	}

// option to create replications: the first object will be placed at transf_relative_to_reference, the other number_of_replications - 1 objects will be placed at replication_transf relative to the previous one
	/// <b> >>> construct replications of a BENT fibre with a given BENDING AXIS, BENDING ANGLE, START and END POINT </b>
	/**
	 *  Constructor to construct replications of a <b> bent </b> fibre with a given <b> bending axis </b>, <b> bending angle </b>, <b> start </b> and <b> end point </b>:
	 *  - sets class variables to default values
	 *  - loads the property file and determines the fibres type
	 *  - sets the variables for the fibre properties and its placement (InitialiseVariables() \& GenerateTransformation())
	 *  - creates materials (DefineMaterials())
	 *  - constructs the volumes (ConstructVolumes())
	 */
	G4Fibre( G4String fibre_property_file,				/**< path to the file containing the G4Fibre%'s property */
		 G4VPhysicalVolume* mother_volume,			/**< volume that should be the G4Fibre%'s mother volume */
		 G4ThreeVector startPoint_relative_to_reference,	/**< G4Fibre%'s start point relative to the reference volume */
		 G4ThreeVector endPoint_relative_to_reference,		/**< G4Fibre%'s end point relative to the reference volume */
		 G4double bending_delta_angle,				/**< G4Fibre%'s bending angle */
		 G4ThreeVector bending_axis,				/**< G4Fibre%'s bending axis */
		 G4VPhysicalVolume* reference_volume,			/**< reference volume relative to which the G4Fibre will be orientated (if 0, the mother volume is the reference volume) */
		 G4Transform3D reference_transformation,		/**< transformation between mother volume and reference volume's mother volume (necessary if the reference volume is located in a different volume) */
		 G4String fibre_name_prefix,				/**< prefix of the G4Fibre%'s volumes' names (it will be extended to distinguish between different G4Fibre%s and different volumes of one G4Fibre) */
		 G4bool onlyInsideMother,				/**< if "true", only G4Fibre parts inside the G4Fibre%'s mother volume will be created */
		 G4bool cutAuntVolumesWithDaughters,			/**< if "true", only NO G4Fibre parts will be created inside the G4Fibre%'s aunt volumes (volumes that have been places into the same volume like the the mother volume) that contain daugther volumes themselves */
		 G4bool startPoint_reflective,				/**< the G4Fibre%'s beginning (start point) should have a reflective layer ("true" or "false") */
		 G4double startPoint_reflectivity,			/**< reflectivity of the G4Fibre%'s beginning (start point) reflective layer */
		 G4bool endPoint_roughened,				/**< the G4Fibre%'s end should be roughened ("true" or "false") */
		 G4double endPoint_sigmaAlpha,				/**< roughness of the G4Fibre%'s end (the parameter defines the standard deviation of the Gaussian distribution of micro-facets' normals around the average surface normal in degree or radian) */
		 G4bool constructSensitiveDetector,			/**< a sensitive detector should be constructed ("true" or "false") */
		 G4bool searchOverlaps,					/**< Geant should search for overlaps when placing the physical volumes of G4Fibre%'s ("true" or "false") */
		 PropertyToolsManager * propertyTools,			/**< pointer to the PropertyToolsManager that should be used */
		 GODDeSS_DataStorage * dataStorage,			/**< pointer to the GODDeSS_DataStorage that should be used */
		 G4Transform3D replication_transf			/**< transformation of each replication, relative to the previous one */
	       )
	// initialising the variables (doing it with default values, "" or "0" is just to prevent errors from wrongly initialised variables), this has to be done in the order of their appearance in the hh-file:
	: SearchOverlaps(searchOverlaps)
	, ConstructSensitiveDetector(constructSensitiveDetector)
	, PropertyTools(propertyTools)
	, DataStorage(dataStorage)
	, MotherVolume_physical(mother_volume)
	, ReferenceVolume_physical(reference_volume)
	, ReferenceVolume_transformation(reference_transformation)
	, StartPoint(startPoint_relative_to_reference)
	, EndPoint(endPoint_relative_to_reference)
	, BendingAxis(bending_axis.perpPart(EndPoint - StartPoint) / bending_axis.perpPart(EndPoint - StartPoint).mag())
	, BendingDeltaAngle(bending_delta_angle)
	, FibreNamePrefix(fibre_name_prefix)
	, OnlyInsideMother(onlyInsideMother)
	, CutAuntVolumesWithDaughters(cutAuntVolumesWithDaughters)
	, Reflective(startPoint_reflective)
	, Reflective_thickness(1 * CLHEP::um)
	, Reflectivity(startPoint_reflectivity)
	, Roughened(endPoint_roughened)
	, Rough_thickness(1e-3 * CLHEP::nm)
	, Roughness(endPoint_sigmaAlpha)
	, ReplicationTransformation(replication_transf)
	{
		if(ReferenceVolume_physical != MotherVolume_physical && ReferenceVolume_physical->GetMotherLogical() != MotherVolume_physical->GetLogicalVolume() && reference_transformation == G4Transform3D()) G4cerr << G4endl << "The reference volume is neither located in the mother volume nor is it the mother volume. This might lead to geometry problems, if no transformation between mother volume and reference volume's mother volume is defined!" << G4endl << G4endl;

		// set default values
		SetDefaults();

		FibreBent = true;
		BendingStartAngle = NAN;
		BendingEndAngle = NAN;
		Reflective_bendingDeltaAngle = NAN;
		Rough_bendingDeltaAngle = NAN;

		Length = NAN;
		FibreTransformation_rel = G4Transform3D();

		// get bending properties
		G4ThreeVector linkingVector = EndPoint - StartPoint;
		BendingCircularCentre = (EndPoint + StartPoint) / 2. - linkingVector.mag() / 2. / tan(BendingDeltaAngle / 2.) * linkingVector.cross(BendingAxis) / linkingVector.mag();
		BendingRadius = linkingVector.mag() / 2. / sin(BendingDeltaAngle / 2.);
		if(Reflective) Reflective_bendingDeltaAngle = 2. * asin(Reflective_thickness / 2. / BendingRadius);
		if(Roughened) Rough_bendingDeltaAngle = 2. * asin(Rough_thickness / 2. / BendingRadius);

		// the obligatory parameters
		FibreProperties.load(fibre_property_file);

		if(FibreProperties.containsNumber("lightOutput") || FibreProperties.containsNumber("lightOutput_rel"))
		{
			IsScinti = true;
			FibreNamePrefix = FibreNamePrefix + "_(scinti)";
		}
		else if(PropertyTools->GetPropertyDistribution(FibreProperties, "epsilon"))
		{
			IsWLS = true;
			FibreNamePrefix = FibreNamePrefix + "_(WLS)";
		}

		// calculate variables and create materials:
		InitialiseVariables();
		GenerateTransformation("bent");
		DefineMaterials();

		// create the volumes
		ConstructVolumes("bent");

		// abort the whole programme, if a critical error occured
		if(CriticalErrorOccured) exit(1);
	}

	/// <b> >>> construct a BENT fibre with a given CIRCULAR CENTRE, BENDING AXIS, BENDING RADIUS, START and END ANGLE </b>
	/**
	 *  Constructor to construct a <b> bent </b> fibre with a given <b> circular centre </b>, <b> bending axis </b>, <b> bending radius </b>, <b> start </b> and <b> end angle </b>:
	 *  - sets class variables to default values
	 *  - loads the property file and determines the fibres type
	 *  - sets the variables for the fibre properties and its placement (InitialiseVariables() \& GenerateTransformation())
	 *  - creates materials (DefineMaterials())
	 *  - constructs the volumes (ConstructVolumes())
	 */
	G4Fibre( G4String fibre_property_file,			/**< path to the file containing the G4Fibre%'s property */
		 G4VPhysicalVolume* mother_volume,		/**< volume that should be the G4Fibre%'s mother volume */
		 G4double bending_start_angle,			/**< G4Fibre%'s start angle (in the bending circle) */
		 G4double bending_end_angle,			/**< G4Fibre%'s end angle (in the bending circle) */
		 G4ThreeVector bending_circular_centre,		/**< circular centre of the G4Fibre%'s bending */
		 G4ThreeVector bending_axis,			/**< G4Fibre%'s bending axis */
		 G4double bending_radius,			/**< G4Fibre%'s bending radius */
		 G4VPhysicalVolume* reference_volume,		/**< reference volume relative to which the G4Fibre will be orientated (if 0, the mother volume is the reference volume) */
		 G4Transform3D reference_transformation,	/**< transformation between mother volume and reference volume's mother volume (necessary if the reference volume is located in a different volume) */
		 G4String fibre_name_prefix,			/**< prefix of the G4Fibre%'s volumes' names (it will be extended to distinguish between different G4Fibre%s and different volumes of one G4Fibre) */
		 G4bool onlyInsideMother,			/**< if "true", only G4Fibre parts inside the G4Fibre%'s mother volume will be created */
		 G4bool cutAuntVolumesWithDaughters,		/**< if "true", only NO G4Fibre parts will be created inside the G4Fibre%'s aunt volumes (volumes that have been places into the same volume like the the mother volume) that contain daugther volumes themselves */
		 G4bool startPoint_reflective,			/**< the G4Fibre%'s beginning (start point) should have a reflective layer ("true" or "false") */
		 G4double startPoint_reflectivity,		/**< reflectivity of the G4Fibre%'s beginning (start point) reflective layer */
		 G4bool endPoint_roughened,			/**< the G4Fibre%'s end should be roughened ("true" or "false") */
		 G4double endPoint_sigmaAlpha,			/**< roughness of the G4Fibre%'s end (the parameter defines the standard deviation of the Gaussian distribution of micro-facets' normals around the average surface normal in degree or radian) */
		 G4bool constructSensitiveDetector,		/**< a sensitive detector should be constructed ("true" or "false") */
		 G4bool searchOverlaps,				/**< Geant should search for overlaps when placing the physical volumes of G4Fibre%'s ("true" or "false") */
		 PropertyToolsManager * propertyTools,		/**< pointer to the PropertyToolsManager that should be used */
		 GODDeSS_DataStorage * dataStorage		/**< pointer to the GODDeSS_DataStorage that should be used */
	       )
	// initialising the variables (doing it with default values, "" or "0" is just to prevent errors from wrongly initialised variables), this has to be done in the order of their appearance in the hh-file:
	: SearchOverlaps(searchOverlaps)
	, ConstructSensitiveDetector(constructSensitiveDetector)
	, PropertyTools(propertyTools)
	, DataStorage(dataStorage)
	, MotherVolume_physical(mother_volume)
	, ReferenceVolume_physical(reference_volume)
	, ReferenceVolume_transformation(reference_transformation)
	, BendingCircularCentre(bending_circular_centre)
	, BendingAxis(bending_axis / bending_axis.mag())
	, BendingRadius(bending_radius)
	, BendingStartAngle(bending_start_angle)
	, BendingEndAngle(bending_end_angle)
	, FibreNamePrefix(fibre_name_prefix)
	, OnlyInsideMother(onlyInsideMother)
	, CutAuntVolumesWithDaughters(cutAuntVolumesWithDaughters)
	, Reflective(startPoint_reflective)
	, Reflective_thickness(1 * CLHEP::um)
	, Reflectivity(startPoint_reflectivity)
	, Roughened(endPoint_roughened)
	, Rough_thickness(1e-3 * CLHEP::nm)
	, Roughness(endPoint_sigmaAlpha)
	{
		if(ReferenceVolume_physical != MotherVolume_physical && ReferenceVolume_physical->GetMotherLogical() != MotherVolume_physical->GetLogicalVolume() && reference_transformation == G4Transform3D()) G4cerr << G4endl << "The reference volume is neither located in the mother volume nor is it the mother volume. This might lead to geometry problems, if no transformation between mother volume and reference volume's mother volume is defined!" << G4endl << G4endl;

		if(BendingEndAngle < BendingStartAngle)
		{
			G4cout << "##########" << G4endl << "# WARNING:" << G4endl << "# bending_end_angle (" << bending_end_angle << ") < bending_start_angle (" << bending_start_angle << "). No bent fibre can be build." << "##########" << G4endl;
			return;
		}

		// set default values
		SetDefaults();

		FibreBent = true;
		BendingDeltaAngle = NAN;
		Reflective_bendingDeltaAngle = NAN;
		Rough_bendingDeltaAngle = NAN;

		StartPoint = G4ThreeVector(NAN, NAN, NAN);
		EndPoint = G4ThreeVector(NAN, NAN, NAN);
		Length = NAN;
		FibreTransformation_rel = G4Transform3D();
		ReplicationTransformation = G4Transform3D();

		// get bending properties
		BendingDeltaAngle = BendingEndAngle - BendingStartAngle;
		if(Reflective) Reflective_bendingDeltaAngle = 2. * asin(Reflective_thickness / 2. / BendingRadius);
		if(Roughened) Rough_bendingDeltaAngle = 2. * asin(Rough_thickness / 2. / BendingRadius);

		// the obligatory parameters
		FibreProperties.load(fibre_property_file);

		if(FibreProperties.containsNumber("lightOutput") || FibreProperties.containsNumber("lightOutput_rel"))
		{
			IsScinti = true;
			FibreNamePrefix = FibreNamePrefix + "_(scinti)";
		}
		else if(PropertyTools->GetPropertyDistribution(FibreProperties, "epsilon"))
		{
			IsWLS = true;
			FibreNamePrefix = FibreNamePrefix + "_(WLS)";
		}

		// calculate variables and create materials:
		InitialiseVariables();
		GenerateTransformation("bent");
		DefineMaterials();

		// create the volumes
		ConstructVolumes("bent");

		// abort the whole programme, if a critical error occured
		if(CriticalErrorOccured) exit(1);
	}

// option to create replications: the first object will be placed at transf_relative_to_reference, the other number_of_replications - 1 objects will be placed at replication_transf relative to the previous one
	/// <b> >>> construct replications of a BENT fibre with a given CIRCULAR CENTRE, BENDING AXIS, BENDING RADIUS, START and END ANGLE </b>
	/**
	 *  Constructor to construct replications of a <b> bent </b> fibre with a given <b> circular centre </b>, <b> bending axis </b>, <b> bending radius </b>, <b> start </b> and <b> end angle </b>:
	 *  - sets class variables to default values
	 *  - loads the property file and determines the fibres type
	 *  - sets the variables for the fibre properties and its placement (InitialiseVariables() \& GenerateTransformation())
	 *  - creates materials (DefineMaterials())
	 *  - constructs the volumes (ConstructVolumes())
	 */
	G4Fibre( G4String fibre_property_file,			/**< path to the file containing the G4Fibre%'s property */
		 G4VPhysicalVolume* mother_volume,		/**< volume that should be the G4Fibre%'s mother volume */
		 G4double bending_start_angle,			/**< G4Fibre%'s start angle (in the bending circle) */
		 G4double bending_end_angle,			/**< G4Fibre%'s end angle (in the bending circle) */
		 G4ThreeVector bending_circular_centre,		/**< circular centre of the G4Fibre%'s bending */
		 G4ThreeVector bending_axis,			/**< G4Fibre%'s bending axis */
		 G4double bending_radius,			/**< G4Fibre%'s bending radius */
		 G4VPhysicalVolume* reference_volume,		/**< reference volume relative to which the G4Fibre will be orientated (if 0, the mother volume is the reference volume) */
		 G4Transform3D reference_transformation,	/**< transformation between mother volume and reference volume's mother volume (necessary if the reference volume is located in a different volume) */
		 G4String fibre_name_prefix,			/**< prefix of the G4Fibre%'s volumes' names (it will be extended to distinguish between different G4Fibre%s and different volumes of one G4Fibre) */
		 G4bool onlyInsideMother,			/**< if "true", only G4Fibre parts inside the G4Fibre%'s mother volume will be created */
		 G4bool cutAuntVolumesWithDaughters,		/**< if "true", only NO G4Fibre parts will be created inside the G4Fibre%'s aunt volumes (volumes that have been places into the same volume like the the mother volume) that contain daugther volumes themselves */
		 G4bool startPoint_reflective,			/**< the G4Fibre%'s beginning (start point) should have a reflective layer ("true" or "false") */
		 G4double startPoint_reflectivity,		/**< reflectivity of the G4Fibre%'s beginning (start point) reflective layer */
		 G4bool endPoint_roughened,			/**< the G4Fibre%'s end should be roughened ("true" or "false") */
		 G4double endPoint_sigmaAlpha,			/**< roughness of the G4Fibre%'s end (the parameter defines the standard deviation of the Gaussian distribution of micro-facets' normals around the average surface normal in degree or radian) */
		 G4bool constructSensitiveDetector,		/**< a sensitive detector should be constructed ("true" or "false") */
		 G4bool searchOverlaps,				/**< Geant should search for overlaps when placing the physical volumes of G4Fibre%'s ("true" or "false") */
		 PropertyToolsManager * propertyTools,		/**< pointer to the PropertyToolsManager that should be used */
		 GODDeSS_DataStorage * dataStorage,		/**< pointer to the GODDeSS_DataStorage that should be used */
		 G4Transform3D replication_transf		/**< transformation of each replication, relative to the previous one */
	       )
	// initialising the variables (doing it with default values, "" or "0" is just to prevent errors from wrongly initialised variables), this has to be done in the order of their appearance in the hh-file:
	: SearchOverlaps(searchOverlaps)
	, ConstructSensitiveDetector(constructSensitiveDetector)
	, PropertyTools(propertyTools)
	, DataStorage(dataStorage)
	, MotherVolume_physical(mother_volume)
	, ReferenceVolume_physical(reference_volume)
	, ReferenceVolume_transformation(reference_transformation)
	, BendingCircularCentre(bending_circular_centre)
	, BendingAxis(bending_axis / bending_axis.mag())
	, BendingRadius(bending_radius)
	, BendingStartAngle(bending_start_angle)
	, BendingEndAngle(bending_end_angle)
	, FibreNamePrefix(fibre_name_prefix)
	, OnlyInsideMother(onlyInsideMother)
	, CutAuntVolumesWithDaughters(cutAuntVolumesWithDaughters)
	, Reflective(startPoint_reflective)
	, Reflective_thickness(1 * CLHEP::um)
	, Reflectivity(startPoint_reflectivity)
	, Roughened(endPoint_roughened)
	, Rough_thickness(1e-3 * CLHEP::nm)
	, Roughness(endPoint_sigmaAlpha)
	, ReplicationTransformation(replication_transf)
	{
		if(ReferenceVolume_physical != MotherVolume_physical && ReferenceVolume_physical->GetMotherLogical() != MotherVolume_physical->GetLogicalVolume() && reference_transformation == G4Transform3D()) G4cerr << G4endl << "The reference volume is neither located in the mother volume nor is it the mother volume. This might lead to geometry problems, if no transformation between mother volume and reference volume's mother volume is defined!" << G4endl << G4endl;

		if(BendingEndAngle < BendingStartAngle)
		{
			G4cout << "##########" << G4endl << "# WARNING:" << G4endl << "# bending_end_angle (" << bending_end_angle << ") < bending_start_angle (" << bending_start_angle << "). No bent fibre can be build." << "##########" << G4endl;
			return;
		}

		// set default values
		SetDefaults();

		FibreBent = true;
		BendingDeltaAngle = NAN;
		Reflective_bendingDeltaAngle = NAN;
		Rough_bendingDeltaAngle = NAN;

		StartPoint = G4ThreeVector(NAN, NAN, NAN);
		EndPoint = G4ThreeVector(NAN, NAN, NAN);
		Length = NAN;
		FibreTransformation_rel = G4Transform3D();

		// get bending properties
		BendingDeltaAngle = BendingEndAngle - BendingStartAngle;
		if(Reflective) Reflective_bendingDeltaAngle = 2. * asin(Reflective_thickness / 2. / BendingRadius);
		if(Roughened) Rough_bendingDeltaAngle = 2. * asin(Rough_thickness / 2. / BendingRadius);

		// the obligatory parameters
		FibreProperties.load(fibre_property_file);

		if(FibreProperties.containsNumber("lightOutput") || FibreProperties.containsNumber("lightOutput_rel"))
		{
			IsScinti = true;
			FibreNamePrefix = FibreNamePrefix + "_(scinti)";
		}
		else if(PropertyTools->GetPropertyDistribution(FibreProperties, "epsilon"))
		{
			IsWLS = true;
			FibreNamePrefix = FibreNamePrefix + "_(WLS)";
		}

		// calculate variables and create materials:
		InitialiseVariables();
		GenerateTransformation("bent");
		DefineMaterials();

		// create the volumes
		ConstructVolumes("bent");

		// abort the whole programme, if a critical error occured
		if(CriticalErrorOccured) exit(1);
	}

	/**
	 *  Destructor (empty)
	 */
	~G4Fibre()
	{
	}



//   #######################   ///
//   #  Getter functions:  #   ///
//   #######################   ///
// basic name of the object:
	/** @return the G4Fibre%'s name prefix */
	G4String GetFibreName()
	{ return FibreNamePrefix; }

// dimensions of the object:
	/**
	 *  @return <b> straight fibres: </b> the fibre's total length
	 *  @return <b> bent fibres: </b> NAN
	 */
	G4double GetFibreLength()
	{
		if(Reflective && Roughened) return Length + Reflective_thickness + Rough_thickness;
		else if(Reflective) return Length + Reflective_thickness;
		else if(Roughened) return Length + Rough_thickness;
		else return Length;
	}

	/**
	 *  @return <b> round fibres: </b> the fibre's total radius
	 *  @return <b> quadratic fibres: </b> NAN
	 */
	G4double GetFibreRadius()
	{ return FibreRadius; }

	/**
	 *  @return <b> round fibres: </b> NAN
	 *  @return <b> quadratic fibres: </b> the fibre's total edge length
	 */
	G4double GetFibreEdgeLength()
	{ return FibreEdgeLength; }

// for bent fibres:
// NOTE: the fibre is originally generated circularly around the z-axis, 0° is parallel to the x-axis and the angle is counted mathematically right-handed around the z-axis
	/**
	 *  @return <b> straight fibres: </b> G4ThreeVector(NAN, NAN, NAN)
	 *  @return <b> bent fibres: </b> the position of the fibre's bending circular centre
	 */
	G4ThreeVector GetCircularCentreOfBentFibre()
	{ return BendingCircularCentre; }

	/**
	 *  @return <b> straight fibres: </b> G4ThreeVector(NAN, NAN, NAN)
	 *  @return <b> bent fibres: </b> the fibre's bending axis
	 */
	G4ThreeVector GetBendingAxisOfBentFibre()
	{ return BendingAxis; }

	/**
	 *  @return <b> straight fibres: </b> NAN
	 *  @return <b> bent fibres: </b> the fibre's bending radius
	 */
	G4double GetBendingRadiusOfBentFibre()
	{ return BendingRadius; }

	/**
	 *  @return <b> straight fibres: </b> NAN
	 *  @return <b> bent fibres: </b> the fibre's bending angle
	 */
	G4double GetBendingDeltaAngleOfBentFibre()
	{ return BendingDeltaAngle; }

	/**
	 *  @return <b> straight fibres: </b> NAN
	 *  @return <b> bent fibres: </b> the fibre's bending start angle
	 */
	G4double GetBendingStartAngleOfBentFibre()
	{ return BendingStartAngle; }

	/**
	 *  @return <b> straight fibres: </b> NAN
	 *  @return <b> bent fibres: </b> the fibre's bending end angle
	 */
	G4double GetBendingEndAngleOfBentFibre()
	{ return BendingEndAngle; }

// relative diameter with respect to the full fibre diameter
// NOTE: relative diameter = relative radius = relative edge length
	/**
	 *  @return <b> if a 3. cladding exists: </b> the relative diameter of the fibre's 3. cladding (compaired to the full diameter)
	 *  @return <b> else: </b> NAN
	 */
	G4double GetRelativeDiameterOfThirdCladding()
	{ return RelativeFibreRadius_Cladding3; }

	/**
	 *  @return <b> if a 2. cladding exists: </b> the relative diameter of the fibre's 2. cladding (compaired to the full diameter)
	 *  @return <b> else: </b> NAN
	 */
	G4double GetRelativeDiameterOfSecondCladding()
	{ return RelativeFibreRadius_Cladding2; }

	/**
	 *  @return <b> if a 1. cladding exists: </b> the relative diameter of the fibre's 1. cladding (compaired to the full diameter)
	 *  @return <b> else: </b> NAN
	 */
	G4double GetRelativeDiameterOfFirstCladding()
	{ return RelativeFibreRadius_Cladding1; }

	/** @return the relative diameter of the fibre's core (compaired to the full diameter) */
	G4double GetRelativeDiameterOfFibreCore()
	{ return RelativeFibreRadius_Core; }

// position and orientation of the object:
	/** @return the transformation of the G4Fibre inside the mother volume */
	G4Transform3D GetFibreInsideMotherTransformation()
	{
		return FibreTransformation_insideMother;
	}

	/** @return the transformation of the G4Fibre outside the mother volume */
	G4Transform3D GetFibreOutsideMotherTransformation()
	{ return FibreTransformation_outsideMother; }

// mother volume of the object:
	/** @return pointer to the G4Fibre%'s mother volume */
	G4VPhysicalVolume * GetMotherVolume_physicalVolume()
	{
		return MotherVolume_physical;
	}

// physical volumes of the object:
	/**
	 *  @return <b> if any G4Fibre%'s physical volume exists inside the mother volume: </b> pointer to the outermost G4Fibre%'s physical volume (in the following order: 3. cladding, 2. cladding, 1. cladding, core), existing inside the mother volume
	 *  @return <b> else: </b> 0
	 */
	G4VPhysicalVolume * GetOutermostVolumeInsideMother_physicalVolume()
	{
		if(Cladding3Exists) return Cladding3_physical[0];
		else if(Cladding2Exists) return Cladding2_physical[0];
		else if(Cladding1Exists) return Cladding1_physical[0];
		else return FibreCore_physical[0];
	}

	/**
	 *  @return <b> if any G4Fibre%'s physical volume exists outside the mother volume: </b> pointer to the outermost G4Fibre%'s physical volume (in the following order: 3. cladding, 2. cladding, 1. cladding, core), existing outside the mother volume
	 *  @return <b> else: </b> 0
	 */
	G4VPhysicalVolume * GetOutermostVolumeOutsideMother_physicalVolume()
	{
		if(Cladding3Exists) return Cladding3_physical[Cladding3_physical.size() - 1];
		else if(Cladding2Exists) return Cladding2_physical[Cladding2_physical.size() - 1];
		else if(Cladding1Exists) return Cladding1_physical[Cladding1_physical.size() - 1];
		else return FibreCore_physical[FibreCore_physical.size() - 1];
	}

	/**
	 *  @return <b> if a physical volume for a G4Fibre%'s 3. cladding exists intside the mother volume: </b> pointer to this physical volume
	 *  @return <b> else: </b> 0
	 */
	G4VPhysicalVolume * GetThirdCladdingInsideMother_physicalVolume()
	{ return Cladding3_physical[0]; }

	/**
	 *  @return <b> if a physical volume for a G4Fibre%'s 3. cladding exists outside the mother volume: </b> pointer to this physical volume
	 *  @return <b> else: </b> 0
	 */
	G4VPhysicalVolume * GetThirdCladdingOutsideMother_physicalVolume()
	{ return Cladding3_physical[Cladding3_physical.size() - 1]; }

	/**
	 *  @return <b> if a physical volume for a G4Fibre%'s 2. cladding exists intside the mother volume: </b> pointer to this physical volume
	 *  @return <b> else: </b> 0
	 */
	G4VPhysicalVolume * GetSecondCladdingInsideMother_physicalVolume()
	{ return Cladding2_physical[0]; }

	/**
	 *  @return <b> if a physical volume for a G4Fibre%'s 2. cladding exists outside the mother volume: </b> pointer to this physical volume
	 *  @return <b> else: </b> 0
	 */
	G4VPhysicalVolume * GetSecondCladdingOutsideMother_physicalVolume()
	{ return Cladding2_physical[Cladding2_physical.size() - 1]; }

	/**
	 *  @return <b> if a physical volume for a G4Fibre%'s 1. cladding exists intside the mother volume: </b> pointer to this physical volume
	 *  @return <b> else: </b> 0
	 */
	G4VPhysicalVolume * GetFirstCladdingInsideMother_physicalVolume()
	{ return Cladding1_physical[0]; }

	/**
	 *  @return <b> if a physical volume for a G4Fibre%'s 1. cladding exists outside the mother volume: </b> pointer to this physical volume
	 *  @return <b> else: </b> 0
	 */
	G4VPhysicalVolume * GetFirstCladdingOutsideMother_physicalVolume()
	{ return Cladding1_physical[Cladding1_physical.size() - 1]; }

	/**
	 *  @return <b> if a physical volume for a G4Fibre%'s core logical intside the mother volume: </b> pointer to this physical volume
	 *  @return <b> else: </b> 0
	 */
	G4VPhysicalVolume * GetFibreCoreInsideMother_physicalVolume()
	{ return FibreCore_physical[0]; }

	/**
	 *  @return <b> if a physical volume for a G4Fibre%'s core exists outside the mother volume: </b> pointer to this physical volume
	 *  @return <b> else: </b> 0
	 */
	G4VPhysicalVolume * GetFibreCoreOutsideMother_physicalVolume()
	{ return FibreCore_physical[FibreCore_physical.size() - 1]; }

	/**
	 *  @return <b> if a physical volume for a G4Fibre%'s reflective end exists inside the mother volume: </b> pointer to this physical volume
	 *  @return <b> else: </b> 0
	 */
	G4VPhysicalVolume * GetReflectiveEndInsideMother_physicalVolume()
	{ return Reflective_physical[0]; }

	/**
	 *  @return <b> if a physical volume for a G4Fibre%'s reflective end exists outside the mother volume: </b> pointer to this physical volume
	 *  @return <b> else: </b> 0
	 */
	G4VPhysicalVolume * GetReflectiveEndOutsideMother_physicalVolume()
	{ return Reflective_physical[Reflective_physical.size() - 1]; }

	/**
	 *  @return <b> if a physical volume for a G4Fibre%'s 3. cladding roughened end exists inside the mother volume: </b> pointer to this physical volume
	 *  @return <b> else: </b> 0
	 */
	G4VPhysicalVolume * GetThirdCladdingRoughenedEndInsideMother_physicalVolume()
	{ return Roughened_cladding3_physical[0]; }

	/**
	 *  @return <b> if a physical volume for a G4Fibre%'s 3. cladding roughened end exists outside the mother volume: </b> pointer to this physical volume
	 *  @return <b> else: </b> 0
	 */
	G4VPhysicalVolume * GetThirdCladdingRoughenedEndOutsideMother_physicalVolume()
	{ return Roughened_cladding3_physical[Roughened_cladding3_physical.size() - 1]; }

	/**
	 *  @return <b> if a physical volume for a G4Fibre%'s 2. cladding roughened end exists inside the mother volume: </b> pointer to this physical volume
	 *  @return <b> else: </b> 0
	 */
	G4VPhysicalVolume * GetSecondCladdingRoughenedEndInsideMother_physicalVolume()
	{ return Roughened_cladding2_physical[0]; }

	/**
	 *  @return <b> if a physical volume for a G4Fibre%'s 2. cladding roughened end exists outside the mother volume: </b> pointer to this physical volume
	 *  @return <b> else: </b> 0
	 */
	G4VPhysicalVolume * GetSecondCladdingRoughenedEndOutsideMother_physicalVolume()
	{ return Roughened_cladding2_physical[Roughened_cladding2_physical.size() - 1]; }

	/**
	 *  @return <b> if a physical volume for a G4Fibre%'s 1. cladding roughened end exists inside the mother volume: </b> pointer to this physical volume
	 *  @return <b> else: </b> 0
	 */
	G4VPhysicalVolume * GetFirstCladdingRoughenedEndInsideMother_physicalVolume()
	{ return Roughened_cladding1_physical[0]; }

	/**
	 *  @return <b> if a physical volume for a G4Fibre%'s 1. cladding roughened end exists outside the mother volume: </b> pointer to this physical volume
	 *  @return <b> else: </b> 0
	 */
	G4VPhysicalVolume * GetFirstCladdingRoughenedEndOutsideMother_physicalVolume()
	{ return Roughened_cladding1_physical[Roughened_cladding1_physical.size() - 1]; }

	/**
	 *  @return <b> if a physical volume for a G4Fibre%'s core roughened end exists inside the mother volume: </b> pointer to this physical volume
	 *  @return <b> else: </b> 0
	 */
	G4VPhysicalVolume * GetFibreCoreRoughenedEndInsideMother_physicalVolume()
	{ return Roughened_fibreCore_physical[0]; }

	/**
	 *  @return <b> if a physical volume for a G4Fibre%'s core roughened end exists outside the mother volume: </b> pointer to this physical volume
	 *  @return <b> else: </b> 0
	 */
	G4VPhysicalVolume * GetFibreCoreRoughenedEndOutsideMother_physicalVolume()
	{ return Roughened_fibreCore_physical[Roughened_fibreCore_physical.size() - 1]; }

// logical volumes of the object:
	/**
	 *  @return <b> if any G4Fibre%'s logical volume exists inside the mother volume: </b> pointer to the outermost G4Fibre%'s logical volume (in the following order: optical cement, 3. cladding, 2. cladding, 1. cladding, core), existing inside the mother volume
	 *  @return <b> else: </b> 0
	 */
	G4LogicalVolume * GetOutermostVolumeInsideMother_logicalVolume()
	{
		if(GetOutermostVolumeInsideMother_physicalVolume()) return GetOutermostVolumeInsideMother_physicalVolume()->GetLogicalVolume();
		else return 0;
	}

	/**
	 *  @return <b> if any G4Fibre%'s logical volume exists outside the mother volume: </b> pointer to the outermost G4Fibre%'s logical volume (in the following order: 3. cladding, 2. cladding, 1. cladding, core), existing outside the mother volume
	 *  @return <b> else: </b> 0
	 */
	G4LogicalVolume * GetOutermostVolumeOutsideMother_logicalVolume()
	{
		if(GetOutermostVolumeOutsideMother_physicalVolume()) return GetOutermostVolumeOutsideMother_physicalVolume()->GetLogicalVolume();
		else return 0;
	}

	/**
	 *  @return <b> if a logical volume for a G4Fibre%'s 3. cladding exists intside the mother volume: </b> pointer to this logical volume
	 *  @return <b> else: </b> 0
	 */
	G4LogicalVolume * GetThirdCladdingInsideMother_logicalVolume()
	{
		if(GetThirdCladdingInsideMother_physicalVolume()) return GetThirdCladdingInsideMother_physicalVolume()->GetLogicalVolume();
		else return 0;
	}

	/**
	 *  @return <b> if a logical volume for a G4Fibre%'s 3. cladding exists outside the mother volume: </b> pointer to this logical volume
	 *  @return <b> else: </b> 0
	 */
	G4LogicalVolume * GetThirdCladdingOutsideMother_logicalVolume()
	{
		if(GetThirdCladdingOutsideMother_physicalVolume()) return GetThirdCladdingOutsideMother_physicalVolume()->GetLogicalVolume();
		else return 0;
	}

	/**
	 *  @return <b> if a logical volume for a G4Fibre%'s 2. cladding exists intside the mother volume: </b> pointer to this logical volume
	 *  @return <b> else: </b> 0
	 */
	G4LogicalVolume * GetSecondCladdingInsideMother_logicalVolume()
	{
		if(GetSecondCladdingInsideMother_physicalVolume()) return GetSecondCladdingInsideMother_physicalVolume()->GetLogicalVolume();
		else return 0;
	}

	/**
	 *  @return <b> if a logical volume for a G4Fibre%'s 2. cladding exists outside the mother volume: </b> pointer to this logical volume
	 *  @return <b> else: </b> 0
	 */
	G4LogicalVolume * GetSecondCladdingOutsideMother_logicalVolume()
	{
		if(GetSecondCladdingOutsideMother_physicalVolume()) return GetSecondCladdingOutsideMother_physicalVolume()->GetLogicalVolume();
		else return 0;
	}

	/**
	 *  @return <b> if a logical volume for a G4Fibre%'s 1. cladding exists intside the mother volume: </b> pointer to this logical volume
	 *  @return <b> else: </b> 0
	 */
	G4LogicalVolume * GetFirstCladdingInsideMother_logicalVolume()
	{
		if(GetFirstCladdingInsideMother_physicalVolume()) return GetFirstCladdingInsideMother_physicalVolume()->GetLogicalVolume();
		else return 0;
	}

	/**
	 *  @return <b> if a logical volume for a G4Fibre%'s 1. cladding exists outside the mother volume: </b> pointer to this logical volume
	 *  @return <b> else: </b> 0
	 */
	G4LogicalVolume * GetFirstCladdingOutsideMother_logicalVolume()
	{
		if(GetFirstCladdingOutsideMother_physicalVolume()) return GetFirstCladdingOutsideMother_physicalVolume()->GetLogicalVolume();
		else return 0;
	}

	/**
	 *  @return <b> if a logical volume for a G4Fibre%'s core logical intside the mother volume: </b> pointer to this logical volume
	 *  @return <b> else: </b> 0
	 */
	G4LogicalVolume * GetFibreCoreInsideMother_logicalVolume()
	{
		if(GetFibreCoreInsideMother_physicalVolume()) return GetFibreCoreInsideMother_physicalVolume()->GetLogicalVolume();
		else return 0;
	}

	/**
	 *  @return <b> if a logical volume for a G4Fibre%'s core exists outside the mother volume: </b> pointer to this logical volume
	 *  @return <b> else: </b> 0
	 */
	G4LogicalVolume * GetFibreCoreOutsideMother_logicalVolume()
	{
		if(GetFibreCoreOutsideMother_physicalVolume()) return GetFibreCoreOutsideMother_physicalVolume()->GetLogicalVolume();
		else return 0;
	}

	/**
	 *  @return <b> if a logical volume for a G4Fibre%'s reflective end exists inside the mother volume: </b> pointer to this logical volume
	 *  @return <b> else: </b> 0
	 */
	G4LogicalVolume * GetReflectiveEndInsideMother_logicalVolume()
	{
		if(GetReflectiveEndInsideMother_physicalVolume()) return GetReflectiveEndInsideMother_physicalVolume()->GetLogicalVolume();
		else return 0;
	}

	/**
	 *  @return <b> if a logical volume for a G4Fibre%'s reflective end exists outside the mother volume: </b> pointer to this logical volume
	 *  @return <b> else: </b> 0
	 */
	G4LogicalVolume * GetReflectiveEndOutsideMother_logicalVolume()
	{
		if(GetReflectiveEndOutsideMother_physicalVolume()) return GetReflectiveEndOutsideMother_physicalVolume()->GetLogicalVolume();
		else return 0;
	}

	/**
	 *  @return <b> if a logical volume for a G4Fibre%'s 3. cladding roughened end exists inside the mother volume: </b> pointer to this logical volume
	 *  @return <b> else: </b> 0
	 */
	G4LogicalVolume * GetThirdCladdingRoughenedEndInsideMother_logicalVolume()
	{
		if(GetThirdCladdingRoughenedEndInsideMother_physicalVolume()) return GetThirdCladdingRoughenedEndInsideMother_physicalVolume()->GetLogicalVolume();
		else return 0;
	}

	/**
	 *  @return <b> if a logical volume for a G4Fibre%'s 3. cladding roughened end exists outside the mother volume: </b> pointer to this logical volume
	 *  @return <b> else: </b> 0
	 */
	G4LogicalVolume * GetThirdCladdingRoughenedEndOutsideMother_logicalVolume()
	{
		if(GetThirdCladdingRoughenedEndOutsideMother_physicalVolume()) return GetThirdCladdingRoughenedEndOutsideMother_physicalVolume()->GetLogicalVolume();
		else return 0;
	}

	/**
	 *  @return <b> if a logical volume for a G4Fibre%'s 2. cladding roughened end exists inside the mother volume: </b> pointer to this logical volume
	 *  @return <b> else: </b> 0
	 */
	G4LogicalVolume * GetSecondCladdingRoughenedEndInsideMother_logicalVolume()
	{
		if(GetSecondCladdingRoughenedEndInsideMother_physicalVolume()) return GetSecondCladdingRoughenedEndInsideMother_physicalVolume()->GetLogicalVolume();
		else return 0;
	}

	/**
	 *  @return <b> if a logical volume for a G4Fibre%'s 2. cladding roughened end exists outside the mother volume: </b> pointer to this logical volume
	 *  @return <b> else: </b> 0
	 */
	G4LogicalVolume * GetSecondCladdingRoughenedEndOutsideMother_logicalVolume()
	{
		if(GetSecondCladdingRoughenedEndOutsideMother_physicalVolume()) return GetSecondCladdingRoughenedEndOutsideMother_physicalVolume()->GetLogicalVolume();
		else return 0;
	}

	/**
	 *  @return <b> if a logical volume for a G4Fibre%'s 1. cladding roughened end exists inside the mother volume: </b> pointer to this logical volume
	 *  @return <b> else: </b> 0
	 */
	G4LogicalVolume * GetFirstCladdingRoughenedEndInsideMother_logicalVolume()
	{
		if(GetFirstCladdingRoughenedEndInsideMother_physicalVolume()) return GetFirstCladdingRoughenedEndInsideMother_physicalVolume()->GetLogicalVolume();
		else return 0;
	}

	/**
	 *  @return <b> if a logical volume for a G4Fibre%'s 1. cladding roughened end exists outside the mother volume: </b> pointer to this logical volume
	 *  @return <b> else: </b> 0
	 */
	G4LogicalVolume * GetFirstCladdingRoughenedEndOutsideMother_logicalVolume()
	{
		if(GetFirstCladdingRoughenedEndOutsideMother_physicalVolume()) return GetFirstCladdingRoughenedEndOutsideMother_physicalVolume()->GetLogicalVolume();
		else return 0;
	}

	/**
	 *  @return <b> if a logical volume for a G4Fibre%'s core roughened end exists inside the mother volume: </b> pointer to this logical volume
	 *  @return <b> else: </b> 0
	 */
	G4LogicalVolume * GetFibreCoreRoughenedEndInsideMother_logicalVolume()
	{
		if(GetFibreCoreRoughenedEndInsideMother_physicalVolume()) return GetFibreCoreRoughenedEndInsideMother_physicalVolume()->GetLogicalVolume();
		else return 0;
	}

	/**
	 *  @return <b> if a logical volume for a G4Fibre%'s core roughened end exists outside the mother volume: </b> pointer to this logical volume
	 *  @return <b> else: </b> 0
	 */
	G4LogicalVolume * GetFibreCoreRoughenedEndOutsideMother_logicalVolume()
	{
		if(GetFibreCoreRoughenedEndOutsideMother_physicalVolume()) return GetFibreCoreRoughenedEndOutsideMother_physicalVolume()->GetLogicalVolume();
		else return 0;
	}

// solid volumes of the object:
	/**
	 *  @return <b> if any G4Fibre%'s solid volume exists inside the mother volume: </b> pointer to the outermost G4Fibre%'s solid volume (in the following order: optical cement, 3. cladding, 2. cladding, 1. cladding, core), existing inside the mother volume
	 *  @return <b> else: </b> 0
	 */
	G4VSolid * GetOutermostVolumeInsideMother_solidVolume()
	{
		if(GetOutermostVolumeInsideMother_logicalVolume()) return GetOutermostVolumeInsideMother_logicalVolume()->GetSolid();
		else return 0;
	}

	/**
	 *  @return <b> if any G4Fibre%'s solid volume exists outside the mother volume: </b> pointer to the outermost G4Fibre%'s solid volume (in the following order: 3. cladding, 2. cladding, 1. cladding, core), existing outside the mother volume
	 *  @return <b> else: </b> 0
	 */
	G4VSolid * GetOutermostVolumeOutsideMother_solidVolume()
	{
		if(GetOutermostVolumeOutsideMother_logicalVolume()) return GetOutermostVolumeOutsideMother_logicalVolume()->GetSolid();
		else return 0;
	}

	/**
	 *  @return <b> if a solid volume for a G4Fibre%'s 3. cladding exists intside the mother volume: </b> pointer to this solid volume
	 *  @return <b> else: </b> 0
	 */
	G4VSolid * GetThirdCladdingInsideMother_solidVolume()
	{
		if(GetThirdCladdingInsideMother_logicalVolume()) return GetThirdCladdingInsideMother_logicalVolume()->GetSolid();
		else return 0;
	}

	/**
	 *  @return <b> if a solid volume for a G4Fibre%'s 3. cladding exists outside the mother volume: </b> pointer to this solid volume
	 *  @return <b> else: </b> 0
	 */
	G4VSolid * GetThirdCladdingOutsideMother_solidVolume()
	{
		if(GetThirdCladdingOutsideMother_logicalVolume()) return GetThirdCladdingOutsideMother_logicalVolume()->GetSolid();
		else return 0;
	}

	/**
	 *  @return <b> if a solid volume for a G4Fibre%'s 3. cladding exists: </b> pointer to its basic solid volume, i.e. the solid volume before the G4Fibre was cut into parts inside and outside the mother volume
	 *  @return <b> else: </b> 0
	 */
	G4VSolid * GetThirdCladding_basicSolidVolume()
	{
		if(GetThirdCladdingInsideMother_solidVolume()) return GetThirdCladdingInsideMother_solidVolume()->GetConstituentSolid(0);
		else if(GetThirdCladdingOutsideMother_solidVolume()) return GetThirdCladdingOutsideMother_solidVolume()->GetConstituentSolid(0);
		else return 0;
	}

	/**
	 *  @return <b> if a solid volume for a G4Fibre%'s 2. cladding exists intside the mother volume: </b> pointer to this solid volume
	 *  @return <b> else: </b> 0
	 */
	G4VSolid * GetSecondCladdingInsideMother_solidVolume()
	{
		if(GetSecondCladdingInsideMother_logicalVolume()) return GetSecondCladdingInsideMother_logicalVolume()->GetSolid();
		else return 0;
	}

	/**
	 *  @return <b> if a solid volume for a G4Fibre%'s 2. cladding exists outside the mother volume: </b> pointer to this solid volume
	 *  @return <b> else: </b> 0
	 */
	G4VSolid * GetSecondCladdingOutsideMother_solidVolume()
	{
		if(GetSecondCladdingOutsideMother_logicalVolume()) return GetSecondCladdingOutsideMother_logicalVolume()->GetSolid();
		else return 0;
	}

	/**
	 *  @return <b> if a solid volume for a G4Fibre%'s 2. cladding exists: </b> pointer to its basic solid volume, i.e. the solid volume before the G4Fibre was cut into parts inside and outside the mother volume
	 *  @return <b> else: </b> 0
	 */
	G4VSolid * GetSecondCladding_basicSolidVolume()
	{
		if(GetSecondCladdingInsideMother_solidVolume()) return GetSecondCladdingInsideMother_solidVolume()->GetConstituentSolid(0);
		if(GetSecondCladdingOutsideMother_solidVolume()) return GetSecondCladdingOutsideMother_solidVolume()->GetConstituentSolid(0);
		else return 0;
	}

	/**
	 *  @return <b> if a solid volume for a G4Fibre%'s 1. cladding exists intside the mother volume: </b> pointer to this solid volume
	 *  @return <b> else: </b> 0
	 */
	G4VSolid * GetFirstCladdingInsideMother_solidVolume()
	{
		if(GetFirstCladdingInsideMother_logicalVolume()) return GetFirstCladdingInsideMother_logicalVolume()->GetSolid();
		else return 0;
	}

	/**
	 *  @return <b> if a solid volume for a G4Fibre%'s 1. cladding exists outside the mother volume: </b> pointer to this solid volume
	 *  @return <b> else: </b> 0
	 */
	G4VSolid * GetFirstCladdingOutsideMother_solidVolume()
	{
		if(GetFirstCladdingOutsideMother_logicalVolume()) return GetFirstCladdingOutsideMother_logicalVolume()->GetSolid();
		else return 0;
	}

	/**
	 *  @return <b> if a solid volume for a G4Fibre%'s 1. cladding exists: </b> pointer to its basic solid volume, i.e. the solid volume before the G4Fibre was cut into parts inside and outside the mother volume
	 *  @return <b> else: </b> 0
	 */
	G4VSolid * GetFirstCladding_basicSolidVolume()
	{
		if(GetFirstCladdingInsideMother_solidVolume()) return GetFirstCladdingInsideMother_solidVolume()->GetConstituentSolid(0);
		if(GetFirstCladdingOutsideMother_solidVolume()) return GetFirstCladdingOutsideMother_solidVolume()->GetConstituentSolid(0);
		else return 0;
	}

	/**
	 *  @return <b> if a solid volume for a G4Fibre%'s core logical intside the mother volume: </b> pointer to this solid volume
	 *  @return <b> else: </b> 0
	 */
	G4VSolid * GetFibreCoreInsideMother_solidVolume()
	{
		if(GetFibreCoreInsideMother_logicalVolume()) return GetFibreCoreInsideMother_logicalVolume()->GetSolid();
		else return 0;
	}

	/**
	 *  @return <b> if a solid volume for a G4Fibre%'s core exists outside the mother volume: </b> pointer to this solid volume
	 *  @return <b> else: </b> 0
	 */
	G4VSolid * GetFibreCoreOutsideMother_solidVolume()
	{
		if(GetFibreCoreOutsideMother_logicalVolume()) return GetFibreCoreOutsideMother_logicalVolume()->GetSolid();
		else return 0;
	}

	/**
	 *  @return <b> if a solid volume for a G4Fibre%'s core exists: </b> pointer to its basic solid volume, i.e. the solid volume before the G4Fibre was cut into parts inside and outside the mother volume
	 *  @return <b> else: </b> 0
	 */
	G4VSolid * GetFibreCore_basicSolidVolume()
	{
		if(GetFibreCoreInsideMother_solidVolume()) return GetFibreCoreInsideMother_solidVolume()->GetConstituentSolid(0);
		if(GetFibreCoreOutsideMother_solidVolume()) return GetFibreCoreOutsideMother_solidVolume()->GetConstituentSolid(0);
		else return 0;
	}

	/**
	 *  @return <b> if a solid volume for a G4Fibre%'s reflective end exists inside the mother volume: </b> pointer to this solid volume
	 *  @return <b> else: </b> 0
	 */
	G4VSolid * GetReflectiveEndInsideMother_solidVolume()
	{
		if(GetReflectiveEndInsideMother_logicalVolume()) return GetReflectiveEndInsideMother_logicalVolume()->GetSolid();
		else return 0;
	}

	/**
	 *  @return <b> if a solid volume for a G4Fibre%'s reflective end exists outside the mother volume: </b> pointer to this solid volume
	 *  @return <b> else: </b> 0
	 */
	G4VSolid * GetReflectiveEndOutsideMother_solidVolume()
	{
		if(GetReflectiveEndOutsideMother_logicalVolume()) return GetReflectiveEndOutsideMother_logicalVolume()->GetSolid();
		else return 0;
	}

	/**
	 *  @return <b> if a solid volume for a G4Fibre%'s reflective end exists: </b> pointer to its basic solid volume, i.e. the solid volume before the G4Fibre was cut into parts inside and outside the mother volume
	 *  @return <b> else: </b> 0
	 */
	G4VSolid * GetReflectiveEnd_basicSolidVolume()
	{
		if(GetReflectiveEndInsideMother_solidVolume()) return GetReflectiveEndInsideMother_solidVolume()->GetConstituentSolid(0);
		if(GetReflectiveEndOutsideMother_solidVolume()) return GetReflectiveEndOutsideMother_solidVolume()->GetConstituentSolid(0);
		else return 0;
	}

	/**
	 *  @return <b> if a solid volume for a G4Fibre%'s 3. cladding roughened end exists inside the mother volume: </b> pointer to this solid volume
	 *  @return <b> else: </b> 0
	 */
	G4VSolid * GetThirdCladdingRoughenedEndInsideMother_solidVolume()
	{
		if(GetThirdCladdingRoughenedEndInsideMother_logicalVolume()) return GetThirdCladdingRoughenedEndInsideMother_logicalVolume()->GetSolid();
		else return 0;
	}

	/**
	 *  @return <b> if a solid volume for a G4Fibre%'s 3. cladding roughened end exists outside the mother volume: </b> pointer to this solid volume
	 *  @return <b> else: </b> 0
	 */
	G4VSolid * GetThirdCladdingRoughenedEndOutsideMother_solidVolume()
	{
		if(GetThirdCladdingRoughenedEndOutsideMother_logicalVolume()) return GetThirdCladdingRoughenedEndOutsideMother_logicalVolume()->GetSolid();
		else return 0;
	}

	/**
	 *  @return <b> if a solid volume for a G4Fibre%'s 3. cladding roughened end exists: </b> pointer to its basic solid volume, i.e. the solid volume before the G4Fibre was cut into parts inside and outside the mother volume
	 *  @return <b> else: </b> 0
	 */
	G4VSolid * GetThirdCladdingRoughenedEnd_basicSolidVolume()
	{
		if(GetThirdCladdingRoughenedEndInsideMother_solidVolume()) return GetThirdCladdingRoughenedEndInsideMother_solidVolume()->GetConstituentSolid(0);
		if(GetThirdCladdingRoughenedEndOutsideMother_solidVolume()) return GetThirdCladdingRoughenedEndOutsideMother_solidVolume()->GetConstituentSolid(0);
		else return 0;
	}

	/**
	 *  @return <b> if a solid volume for a G4Fibre%'s 2. cladding roughened end exists inside the mother volume: </b> pointer to this solid volume
	 *  @return <b> else: </b> 0
	 */
	G4VSolid * GetSecondCladdingRoughenedEndInsideMother_solidVolume()
	{
		if(GetSecondCladdingRoughenedEndInsideMother_logicalVolume()) return GetSecondCladdingRoughenedEndInsideMother_logicalVolume()->GetSolid();
		else return 0;
	}

	/**
	 *  @return <b> if a solid volume for a G4Fibre%'s 2. cladding roughened end exists outside the mother volume: </b> pointer to this solid volume
	 *  @return <b> else: </b> 0
	 */
	G4VSolid * GetSecondCladdingRoughenedEndOutsideMother_solidVolume()
	{
		if(GetSecondCladdingRoughenedEndOutsideMother_logicalVolume()) return GetSecondCladdingRoughenedEndOutsideMother_logicalVolume()->GetSolid();
		else return 0;
	}

	/**
	 *  @return <b> if a solid volume for a G4Fibre%'s 2. cladding roughened end exists: </b> pointer to its basic solid volume, i.e. the solid volume before the G4Fibre was cut into parts inside and outside the mother volume
	 *  @return <b> else: </b> 0
	 */
	G4VSolid * GetSecondCladdingRoughenedEnd_basicSolidVolume()
	{
		if(GetSecondCladdingRoughenedEndInsideMother_solidVolume()) return GetSecondCladdingRoughenedEndInsideMother_solidVolume()->GetConstituentSolid(0);
		if(GetSecondCladdingRoughenedEndOutsideMother_solidVolume()) return GetSecondCladdingRoughenedEndOutsideMother_solidVolume()->GetConstituentSolid(0);
		else return 0;
	}

	/**
	 *  @return <b> if a solid volume for a G4Fibre%'s 1. cladding roughened end exists inside the mother volume: </b> pointer to this solid volume
	 *  @return <b> else: </b> 0
	 */
	G4VSolid * GetFirstCladdingRoughenedEndInsideMother_solidVolume()
	{
		if(GetFirstCladdingRoughenedEndInsideMother_logicalVolume()) return GetFirstCladdingRoughenedEndInsideMother_logicalVolume()->GetSolid();
		else return 0;
	}

	/**
	 *  @return <b> if a solid volume for a G4Fibre%'s 1. cladding roughened end exists outside the mother volume: </b> pointer to this solid volume
	 *  @return <b> else: </b> 0
	 */
	G4VSolid * GetFirstCladdingRoughenedEndOutsideMother_solidVolume()
	{
		if(GetFirstCladdingRoughenedEndOutsideMother_logicalVolume()) return GetFirstCladdingRoughenedEndOutsideMother_logicalVolume()->GetSolid();
		else return 0;
	}

	/**
	 *  @return <b> if a solid volume for a G4Fibre%'s 1. cladding roughened end exists: </b> pointer to its basic solid volume, i.e. the solid volume before the G4Fibre was cut into parts inside and outside the mother volume
	 *  @return <b> else: </b> 0
	 */
	G4VSolid * GetFirstCladdingRoughenedEnd_basicSolidVolume()
	{
		if(GetFirstCladdingRoughenedEndInsideMother_solidVolume()) return GetFirstCladdingRoughenedEndInsideMother_solidVolume()->GetConstituentSolid(0);
		if(GetFirstCladdingRoughenedEndOutsideMother_solidVolume()) return GetFirstCladdingRoughenedEndOutsideMother_solidVolume()->GetConstituentSolid(0);
		else return 0;
	}

	/**
	 *  @return <b> if a solid volume for a G4Fibre%'s core roughened end exists inside the mother volume: </b> pointer to this solid volume
	 *  @return <b> else: </b> 0
	 */
	G4VSolid * GetFibreCoreRoughenedEndInsideMother_solidVolume()
	{
		if(GetFibreCoreRoughenedEndInsideMother_logicalVolume()) return GetFibreCoreRoughenedEndInsideMother_logicalVolume()->GetSolid();
		else return 0;
	}

	/**
	 *  @return <b> if a solid volume for a G4Fibre%'s core roughened end exists outside the mother volume: </b> pointer to this solid volume
	 *  @return <b> else: </b> 0
	 */
	G4VSolid * GetFibreCoreRoughenedEndOutsideMother_solidVolume()
	{
		if(GetFibreCoreRoughenedEndOutsideMother_logicalVolume()) return GetFibreCoreRoughenedEndOutsideMother_logicalVolume()->GetSolid();
		else return 0;
	}

	/**
	 *  @return <b> if a solid volume for a G4Fibre%'s core roughened end exists: </b> pointer to its basic solid volume, i.e. the solid volume before the G4Fibre was cut into parts inside and outside the mother volume
	 *  @return <b> else: </b> 0
	 */
	G4VSolid * GetFibreCoreRoughenedEnd_basicSolidVolume()
	{
		if(GetFibreCoreRoughenedEndInsideMother_solidVolume()) return GetFibreCoreRoughenedEndInsideMother_solidVolume()->GetConstituentSolid(0);
		if(GetFibreCoreRoughenedEndOutsideMother_solidVolume()) return GetFibreCoreRoughenedEndOutsideMother_solidVolume()->GetConstituentSolid(0);
		else return 0;
	}

// materials of the object:
	/**
	 *  @return <b> if a 3. cladding exists: </b> pointer to the material of the G4Fibre%'s 3. cladding
	 *  @return <b> else: </b> 0
	 */
	G4Material * GetThirdCladdingMaterial()
	{ return Material_Cladding3; }

	/**
	 *  @return <b> if a 2. cladding exists: </b> pointer to the material of the G4Fibre%'s 2. cladding
	 *  @return <b> else: </b> 0
	 */
	G4Material * GetSecondCladdingMaterial()
	{ return Material_Cladding2; }

	/**
	 *  @return <b> if a 1. cladding exists: </b> pointer to the material of the G4Fibre%'s 1. cladding
	 *  @return <b> else: </b> 0
	 */
	G4Material * GetFirstCladdingMaterial()
	{ return Material_Cladding1; }

	/** @return pointer to the material of the G4Fibre%'s core */
	G4Material * GetFibreCoreMaterial()
	{ return Material_FibreCore; }

// optical surfaces of the object:
	/**
	 *  @return <b> if the G4Fibre has a reflective end: </b> pointer to the optical surface of the G4Fibre%'s reflective end
	 *  @return <b> else: </b> 0
	 */
	G4OpticalSurface * GetReflectiveEndOpticalSurface()
	{ return OptSurf_reflective; }

	/**
	 *  @return <b> if the G4Fibre has a roughened end: </b> pointer to the optical surface of the G4Fibre%'s roughened end
	 *  @return <b> else: </b> 0
	 */
	G4OpticalSurface * GetRoughenedEndOpticalSurface()
	{ return OptSurf_roughened; }

// sensitive detector:
	/** @return G4bool, if the G4Fibre has a sensitive detector */
	G4bool HasSensitiveDetector()
	{ return ConstructSensitiveDetector; }

	/** @return pointer to the sensitive detector */
	FibreSensitiveDetector * GetSensitiveDetector()
	{ return ((FibreSensitiveDetector *) G4SDManager::GetSDMpointer()->FindSensitiveDetector("PhotonDetectorSD", false)); }

// other properties of the object:
	/** @return G4bool, if the fibre is bent */
	G4bool IsFibreBent()
	{ return FibreBent; }

	/** @return G4bool, if the fibre is round */
	G4bool IsFibreRound()
	{ return FibreRound; }

	/** @return G4bool, if it is a scintillating fibre */
	G4bool IsScintillatingFibre()
	{ return IsScinti; }

	/** @return G4bool, if it is a wave-length-shifting fibre */
	G4bool IsWLSFibre()
	{ return IsWLS; }

	/** @return G4bool, if it is a light-guiding fibre (neither wave-length-shifting nor scintillating) */
	G4bool IsLightGuidingFibre()
	{
		if(!IsWLS && !IsScinti) return true;
		else return false;
	}

	/** @return G4bool, if a 3. cladding exists */
	G4bool DoesThirdCladdingExist()
	{ return Cladding3Exists; }

	/** @return G4bool, if a 2. cladding exists */
	G4bool DoesSecondCladdingExist()
	{ return Cladding2Exists; }

	/** @return G4bool, if a 1. cladding exists */
	G4bool DoesFirstCladdingExist()
	{ return Cladding1Exists; }

	/** @return G4bool, if the fibre has a reflective end */
	G4bool FibreHasReflectiveEnd()
	{ return Reflective; }

	/** @return G4bool, if the fibre has a roughened end */
	G4bool FibreHasRoughenedEnds()
	{ return Roughened; }

	/**
	 *  @return <b> if the fibre has a reflective end: </b> reflectivity of the fibre's reflective end
	 *  @return <b> else: </b> NAN
	 */
	G4double GetFibreEndReflectivity()
	{
		if(Reflective) return Reflectivity;
		else return NAN;
	}

	/**
	 *  @return <b> if the fibre has a roughened end: </b> roughness of the fibre's roughened end
	 *  @return <b> else: </b> NAN
	 */
	G4double	 GetFibreEndRoughness()
	{
		if(Roughened) return Roughness;
		else return NAN;
	}

private:
	void SetDefaults();

	void InitialiseVariables();
	void GenerateTransformation(G4String fibreType	/**< which type of G4Fibre should be created (bent or straight) */
				   );

	void DefineMaterials();

	void DefineCoreMaterialProperties();
	void DefineCladding1MaterialProperties();
	void DefineCladding2MaterialProperties();
	void DefineCladding3MaterialProperties();

	void ConstructSurface();
	void DefineReflectiveSurfacesProperties();
	void DefineRoughenedSurfacesProperties();


	void ConstructVolumes(G4String fibreType	/**< which type of G4Fibre should be created (bent or straight) */
			     );

	std::vector<G4VPhysicalVolume *>  ConstructFibreLayerPhysical( G4Transform3D cutTransformation,	/**< transformation for cutting the G4Fibre into parts inside and outside the mother volume */
								       G4Transform3D transformation,	/**< transformation for placing the G4Fibre layer into the mother volume */
								       G4String nameBase,		/**< base of the G4Fibre%'s volumes' names (it will be extended to distinguish between different volumes belonging to one G4Fibre) */
								       G4double fibreRadiusMin_rel,	/**< G4Fibre layer's relative inner radius with respect to the G4Fibre%'s full radius */
								       G4double fibreRadiusMax_rel,	/**< G4Fibre layer's relative outer radius with respect to the G4Fibre%'s full radius */
								       G4Material * material,		/**< G4Fibre layer's material */
								       G4Colour colour_in,		/**< G4Fibre layer's colour for parts inside the mother volume (for visualisation) */
								       G4Colour colour_out,		/**< G4Fibre layer's colour for parts outside the mother volume (for visualisation) */
								       G4String fibreType,		/**< which type of G4Fibre should be created (bent or straight) */
								       G4String fibrePart = ""		/**< which part of the G4Fibre should be created (roughened end, reflective end or normal part) */
								     );


	std::vector<boost::any> ConstructFibreLayerLogical( G4Transform3D cutTransformation,	/**< transformation for cutting the G4Fibre into parts inside and outside the mother volume */
							    G4Transform3D transformation,	/**< transformation for placing the G4Fibre layer into the mother volume */
							    G4String nameBase,			/**< base of the G4Fibre%'s volumes' names (it will be extended to distinguish between different volumes belonging to one G4Fibre) */
							    G4double fibreRadiusMin_rel,		/**< G4Fibre layer's relative inner radius with respect to the G4Fibre%'s full radius */
							    G4double fibreRadiusMax_rel,		/**< G4Fibre layer's relative outer radius with respect to the G4Fibre%'s full radius */
							    G4Material * material,		/**< G4Fibre layer's material */
							    G4Colour colour_in,			/**< G4Fibre layer's colour for parts inside the mother volume (for visualisation) */
							    G4Colour colour_out,			/**< G4Fibre layer's colour for parts outside the mother volume (for visualisation) */
							    G4String fibreType,			/**< which type of G4Fibre should be created (bent or straight) */
							    G4String fibrePart			/**< which part of the G4Fibre should be created (roughened end, reflective end or normal part) */
							  );



	std::vector<G4VPhysicalVolume *> findGrandMotherAndAuntVolumes(G4bool cutAuntVolumesWithDaughters);



	G4bool CriticalErrorOccured;
	G4bool SearchOverlaps;
	G4bool ConstructSensitiveDetector;
	PropertyToolsManager * PropertyTools;
	GODDeSS_DataStorage * DataStorage;
	G4VPhysicalVolume * MotherVolume_physical;
	G4VSolid * MotherVolume_solid;
	G4VPhysicalVolume * ReferenceVolume_physical;
	G4Transform3D ReferenceVolume_transformation;
	std::vector<G4VPhysicalVolume *> GrandMotherAndAuntVolumes;

// Materials & Elements
	G4Material* Material_FibreCore;
	G4Material* Material_Cladding1;
	G4Material* Material_Cladding2;
	G4Material* Material_Cladding3;

// Fibre
	Properties FibreProperties;
	G4ThreeVector StartPoint;
	G4ThreeVector EndPoint;
	G4ThreeVector BendingCircularCentre;
	G4ThreeVector BendingAxis;
	G4double BendingRadius;
	G4double BendingDeltaAngle;
	G4double BendingStartAngle;
	G4double BendingEndAngle;
	G4double Length;
	G4Transform3D FibreTransformation_rel;
	G4String FibreNamePrefix;
	G4bool OnlyInsideMother;
	G4bool CutAuntVolumesWithDaughters;
	G4bool FibreBent;
	G4bool FibreRound;
	G4bool IsScinti;
	G4bool IsWLS;
	G4bool Cladding1Exists;
	G4bool Cladding2Exists;
	G4bool Cladding3Exists;
	G4double FibreRadius;
	G4double RelativeFibreRadius_Core;
	G4double RelativeFibreRadius_Cladding1;
	G4double RelativeFibreRadius_Cladding2;
	G4double RelativeFibreRadius_Cladding3;
	G4double FibreEdgeLength;
	G4Transform3D FibreTransformation_insideMother;
	G4Transform3D FibreTransformation_outsideMother;
	std::vector<G4VPhysicalVolume *> FibreCore_physical;
	std::vector<G4VPhysicalVolume *> Cladding1_physical;
	std::vector<G4VPhysicalVolume *> Cladding2_physical;
	std::vector<G4VPhysicalVolume *> Cladding3_physical;

// Reflective fibre end
	G4bool Reflective;
	G4double Reflective_thickness;
	G4double Reflective_bendingDeltaAngle;
	G4double Reflectivity;
	G4Transform3D ReflectiveTransformation_insideMother;
	G4Transform3D ReflectiveTransformation_outsideMother;
	std::vector<G4VPhysicalVolume *> Reflective_physical;
	G4OpticalSurface * OptSurf_reflective;

// Roughened fibre end
	G4bool Roughened;
	G4double Rough_thickness;
	G4double Rough_bendingDeltaAngle;
	G4double Roughness;
	G4Transform3D RoughenedTransformation_insideMother;
	G4Transform3D RoughenedTransformation_outsideMother;
	std::vector<G4VPhysicalVolume *> Roughened_cladding3_physical;
	std::vector<G4VPhysicalVolume *> Roughened_cladding2_physical;
	std::vector<G4VPhysicalVolume *> Roughened_cladding1_physical;
	std::vector<G4VPhysicalVolume *> Roughened_fibreCore_physical;
	G4OpticalSurface * OptSurf_roughened;
	G4OpticalSurface * OptSurf_nonroughened;


	G4Transform3D ReplicationTransformation;
};

#endif
